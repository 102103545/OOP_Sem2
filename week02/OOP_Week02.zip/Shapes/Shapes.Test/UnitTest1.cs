﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Shapes.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ConstructorTest()
        {
            //Arrange
            
        }
    }
}
